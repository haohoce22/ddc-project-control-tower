DDC Project Control Tower v2
============================

Mục đích:
- Theo dõi các dự án kết cấu thép theo góc nhìn nhân viên kế hoạch.
- Bao gồm 4 ưu tiên chính: dashboard tổng quan, Gantt tiến độ, vật tư/tồn kho, cảnh báo ưu tiên xử lý.

Cách mở:
1. Tải file ddc_project_control_tower_v2.html.
2. Mở bằng Google Chrome hoặc Microsoft Edge.
3. Dữ liệu được lưu trên trình duyệt bằng LocalStorage, không cần backend.

Cách deploy GitHub/Netlify:
1. Dùng file index.html trong package.
2. Upload index.html lên repo GitHub.
3. Kết nối repo với Netlify hoặc GitHub Pages.

Các tab chính:
- Tổng quan: KPI, tiến độ dự án, khối lượng theo nhà máy, công đoạn.
- Gantt tiến độ: timeline theo Plan Start/Plan Finish.
- Vật tư: Required, Received, Remaining, ETA, Status.
- Ưu tiên xử lý: tự chấm điểm dựa trên Delay/Hold/Due soon/Process.
- Dữ liệu: thêm hạng mục, import/export JSON, download CSV.

Gợi ý chuẩn hóa dữ liệu thật:
Các cột cần có:
Project, Package, Zone, Mark, Factory, Process, Weight, Plan Start, Plan Finish, Actual Finish, Status, Reason.

Status nên dùng thống nhất:
Waiting, In Progress, Completed, Delay, Hold.

DDC Project Control Tower - Hướng dẫn sử dụng nhanh

1. Mở file ddc_project_control_tower.html bằng Chrome hoặc Edge.
2. Web app chạy offline, không cần cài phần mềm.
3. Các phần chính:
   - Tổng quan dự án: xem tổng khối lượng, % hoàn thành, khối lượng trễ.
   - Gantt tiến độ: xem kế hoạch theo mốc thời gian.
   - Vật tư & tồn kho: theo dõi vật tư ảnh hưởng Fitup/Welding/Packing.
   - Cảnh báo ưu tiên: tự động báo hạng mục trễ, thiếu vật tư, tải nhà máy cao.
   - Dữ liệu sản xuất: nhập/sửa/xóa dữ liệu.
4. Dữ liệu được lưu trong trình duyệt bằng localStorage.
5. Nút Export JSON dùng để backup toàn bộ dữ liệu.
6. Nút Import JSON dùng để phục hồi dữ liệu đã backup.
7. Nút Export CSV dùng để xuất bảng dữ liệu sản xuất ra Excel.
8. Có thể upload file HTML này lên GitHub và deploy bằng Netlify/GitHub Pages.

Gợi ý đặt tên repository trên GitHub:
ddc-project-control-tower

Cấu trúc khi upload GitHub:
- index.html  (đổi tên từ ddc_project_control_tower.html)
- README.txt
